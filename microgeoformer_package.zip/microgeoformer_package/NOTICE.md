# Notice

MicroGeoFormer is an independent implementation. It is benchmarked in the
accompanying paper against re-implementations capturing the core design
logic of two related published tools, but does not reuse code from either:

- **Locator** — Battey, C. J., Ralph, P. L. & Kern, A. D. Predicting geographic
  location from genetic variation with deep neural networks. *eLife* 9,
  e54507 (2020). https://github.com/kr-colab/locator
- **GeoGenIE** — Martin, B. T., Zbinden, Z. D., Douglas, M. E., Douglas, M. R.
  & Chafin, T. K. GeoGenIE: a deep learning approach to predict geographic
  provenance of biodiversity samples from genomic SNPs. *Bioinformatics
  Advances* 5, vbaf250 (2025). https://github.com/btmartin721/GeoGenIE

MicroGeoFormer's distinguishing components — the per-locus attention gate
and the Mendelian-resampling augmentation strategy for sparse reference
panels — are original to this work.
